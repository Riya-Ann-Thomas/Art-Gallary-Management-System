<?php
$con=mysqli_connect("localhost","root","","dbms") or die(mysqli_error($con));
//$con=mysqli_connect("localhost","root","","store") or die(mysqli_error($con));
?>
